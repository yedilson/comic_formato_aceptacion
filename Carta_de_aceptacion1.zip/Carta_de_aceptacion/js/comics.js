
    /**
    * Esta función se encarga de cargar el xml.
    */
    function cargararchivo(archivo, etiqueta, locacion) 
    {
      var xmlhttp = new XMLHttpRequest();
      xmlhttp.onreadystatechange = function() 
                {
                    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) 
                      {
                        console.log( "Ha cargado el xml." );
                        imprimir(xmlhttp, etiqueta, locacion);
                      }
                  };

            xmlhttp.open("GET", archivo, true);
            xmlhttp.send();
    }

    /**
    * Una vez el xml ha sido cargado, se ejecuta la construcción de nuevo contenido.
    *
    */
    function imprimir(xml, etiqueta, locacion) 
        {
            var i;
            var xmlDoc = xml.responseXML;
            var contenido="";
            var y = xmlDoc.getElementsByTagName("comic")
            var x = xmlDoc.getElementsByTagName(etiqueta);
            var num=1;
          
            console.log( "Ha empezado la alteración del html." );
            contenido += "<center><h1 style=' background-color:rgba(255, 255, 255, .8); font:"+y[0].getElementsByTagName("fuentet")[0].childNodes[0].nodeValue+"'>"+y[0].getElementsByTagName("titulo")[0].childNodes[0].nodeValue+"</h1></center>";
            contenido +="<div id='scroll' style='overflow:auto; height:600px;''>";
            for (i = 0; i <x.length; i++) 
              {
              contenido += "<center><div id='capitulo'style=' width:"+x[i].getElementsByTagName("largo")[0].childNodes[0].nodeValue+"; height:"+x[i].getElementsByTagName("altura")[0].childNodes[0].nodeValue+"; background-size:"+x[i].getElementsByTagName("tamanofondo")[0].childNodes[0].nodeValue+"; background-image:url("+x[i].getElementsByTagName("colorfondo")[0].childNodes[0].nodeValue+"); border-radius:"+x[i].getElementsByTagName("borderadio")[0].childNodes[0].nodeValue+"; display:"+x[i].getElementsByTagName("display")[0].childNodes[0].nodeValue+"; position:"+x[i].getElementsByTagName("posicion")[0].childNodes[0].nodeValue+"; padding:"+x[i].getElementsByTagName("padding")[0].childNodes[0].nodeValue+"; margin:"+x[i].getElementsByTagName("margen")[0].childNodes[0].nodeValue+";'>"+(i+num);
              contenido += "<div id='comentarios'style='width:"+x[i].getElementsByTagName("largocomentarios")[0].childNodes[0].nodeValue+"; display:"+x[i].getElementsByTagName("displaycomentarios")[0].childNodes[0].nodeValue+";'>"
              contenido += "<div id='comentario1' style=' font:"+x[i].getElementsByTagName("fuentea")[0].childNodes[0].nodeValue+"; width:"+x[i].getElementsByTagName("largocomentario1")[0].childNodes[0].nodeValue+"; height:"+x[i].getElementsByTagName("alturacomentario1")[0].childNodes[0].nodeValue+"; background-color:"+x[i].getElementsByTagName("colorfondocomentario1")[0].childNodes[0].nodeValue+"; border-radius:"+x[i].getElementsByTagName("borderadiocomentario1")[0].childNodes[0].nodeValue+"; display:"+x[i].getElementsByTagName("displaycomentario1")[0].childNodes[0].nodeValue+"; position:"+x[i].getElementsByTagName("posicioncomentario1")[0].childNodes[0].nodeValue+"; padding:"+x[i].getElementsByTagName("paddingcomentario1")[0].childNodes[0].nodeValue+"; float:"+x[i].getElementsByTagName("floatcomentario1")[0].childNodes[0].nodeValue+"; text-aling:"+x[i].getElementsByTagName("alineacioncomentario1")[0].childNodes[0].nodeValue+";'>"+x[i].getElementsByTagName("comentario1")[0].childNodes[0].nodeValue+"</div>";
              contenido += "<div id='comentario2' style=' font:"+x[i].getElementsByTagName("fuentea")[0].childNodes[0].nodeValue+"; width:"+x[i].getElementsByTagName("largocomentario2")[0].childNodes[0].nodeValue+"; height:"+x[i].getElementsByTagName("alturacomentario2")[0].childNodes[0].nodeValue+"; background-color:"+x[i].getElementsByTagName("colorfondocomentario2")[0].childNodes[0].nodeValue+"; border-radius:"+x[i].getElementsByTagName("borderadiocomentario2")[0].childNodes[0].nodeValue+"; display:"+x[i].getElementsByTagName("displaycomentario2")[0].childNodes[0].nodeValue+"; position:"+x[i].getElementsByTagName("posicioncomentario2")[0].childNodes[0].nodeValue+"; padding:"+x[i].getElementsByTagName("paddingcomentario2")[0].childNodes[0].nodeValue+"; float:"+x[i].getElementsByTagName("floatcomentario2")[0].childNodes[0].nodeValue+"; text-aling:"+x[i].getElementsByTagName("alineacioncomentario2")[0].childNodes[0].nodeValue+";'>"+x[i].getElementsByTagName("comentario2")[0].childNodes[0].nodeValue+"</div>";
              contenido += "</div>";
              contenido += "<div  style='height:"+x[i].getElementsByTagName("altoimg1")[0].childNodes[0].nodeValue+"; display:"+x[i].getElementsByTagName("displayimg1")[0].childNodes[0].nodeValue+"; position:"+x[i].getElementsByTagName("posicionimg1")[0].childNodes[0].nodeValue+"; float:"+x[i].getElementsByTagName("floatimg1")[0].childNodes[0].nodeValue+";'><img src='"+x[i].getElementsByTagName("img1")[0].childNodes[0].nodeValue+"' style='height:"+x[i].getElementsByTagName("altoimg1")[0].childNodes[0].nodeValue+";'></div>";
              contenido += "<div  style='height:"+x[i].getElementsByTagName("altoimg2")[0].childNodes[0].nodeValue+"; display:"+x[i].getElementsByTagName("displayimg2")[0].childNodes[0].nodeValue+"; position:"+x[i].getElementsByTagName("posicionimg2")[0].childNodes[0].nodeValue+"; float:"+x[i].getElementsByTagName("floatimg2")[0].childNodes[0].nodeValue+";'><img src='"+x[i].getElementsByTagName("img2")[0].childNodes[0].nodeValue+"'style='height:"+x[i].getElementsByTagName("altoimg2")[0].childNodes[0].nodeValue+";'></div>";
              contenido+=  "<div id='cerca' style=' background-size:"+x[i].getElementsByTagName("tamanocerca")[0].childNodes[0].nodeValue+"; background-image:url("+x[i].getElementsByTagName("fondocerca")[0].childNodes[0].nodeValue+"); height:"+x[i].getElementsByTagName("altocerca")[0].childNodes[0].nodeValue+"; width:"+x[i].getElementsByTagName("largocerca")[0].childNodes[0].nodeValue+"; display:"+x[i].getElementsByTagName("displaycerca")[0].childNodes[0].nodeValue+"; position:"+x[i].getElementsByTagName("posicioncerca")[0].childNodes[0].nodeValue+"; top:"+x[i].getElementsByTagName("bajandocerca")[0].childNodes[0].nodeValue+"; left:"+x[i].getElementsByTagName("movercerca")[0].childNodes[0].nodeValue+";'>";
              contenido+= "</div>";
              contenido+= "</div>";
              }
              contenido+= "</div>";
            document.getElementById(locacion).innerHTML = contenido;
        }
